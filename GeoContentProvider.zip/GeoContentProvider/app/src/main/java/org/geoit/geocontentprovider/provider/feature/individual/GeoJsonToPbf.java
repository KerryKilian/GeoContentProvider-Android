package org.geoit.geocontentprovider.provider.feature.individual;

public class GeoJsonToPbf {

}
